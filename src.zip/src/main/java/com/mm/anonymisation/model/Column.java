package com.mm.anonymisation.model;

public record Column(String name, Integer position) {

}
