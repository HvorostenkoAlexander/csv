package com.mm.anonymisation.service.generator;

public interface FieldGenerator {

  String generate();
}
