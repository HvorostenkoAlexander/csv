update user_account
set email='technical.verifier@solva.kz'
where id = 1651149;